"""
Movella DOT Quaternion Data Streaming package.
"""