"""
Utility modules for the Movella DOT Quaternion Data Streaming package.
"""